<?php

return [
    'theme' => env('THEME', 'default').'.',
];
